# Hapity Joomla

##Author
#### EgenieNext 
URL : http://www.egenienext.com/

##Description 

Hapity publish broadcasts recorded from https://hapity.com or from Hapity website or mobile app (https://play.google.com/store/apps/details?id=com.app.hapity&hl=en)

Major features in Hapity include:

* Automatically publish video broadcasts from Hapity website or Hapity mobile app
* Enable/Disable automatic broadcasts publishing
